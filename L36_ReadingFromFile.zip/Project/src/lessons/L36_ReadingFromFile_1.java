package lessons;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class L36_ReadingFromFile_1 {

	public static void main(String[] args) throws FileNotFoundException {
		String separator = File.separator;

		String filePath = separator + "home" +
						  separator + "user" +
						  separator + "java" +
						  separator + "IPs.txt";

		File ipFile = new File(filePath);

		Scanner ipFileScanner = new Scanner(ipFile);

		while (ipFileScanner.hasNextLine()) {
			System.out.println(ipFileScanner.nextLine());
		}

		ipFileScanner.close();
	}
}