package lessons;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

class L36_ReadingFromFile_3 {

	public static void main(String[] args) throws FileNotFoundException {
		String separator = File.separator;

		String filePath = separator + "home" +
						  separator + "user" +
						  separator + "java" +
						  separator + "numbers.txt";

		File numbersFile = new File(filePath);

		Scanner numbersFileScanner = new Scanner(numbersFile);

		String numberLine = numbersFileScanner.nextLine();

		numbersFileScanner.close();

		String[] numbersStringType = numberLine.split(":");

		System.out.println(Arrays.toString(numbersStringType) + " - String Array");

		int[] numbersIntType = new int[10];

		int counter = 0;
		for (String number : numbersStringType) {
			numbersIntType[counter++] = Integer.parseInt(number);
		}

		System.out.println(Arrays.toString(numbersIntType) + " - Integer Array");
	}
}