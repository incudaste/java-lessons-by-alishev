package lessons;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class L36_ReadingFromFile_4 {

	public static void main(String[] args) throws FileNotFoundException {
		File messageFile = new File("message.txt");

		Scanner messageFileScanner = new Scanner(messageFile);

		String message = messageFileScanner.nextLine();

		System.out.println(message);

		messageFileScanner.close();
	}
}