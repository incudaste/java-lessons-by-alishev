package lessons;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

class L36_ReadingFromFile_2 {

	public static void main(String[] args) throws FileNotFoundException {
		String separator = File.separator;

		String filePath = separator + "home" +
						  separator + "user" +
						  separator + "java" +
						  separator + "names.txt";

		File namesFile = new File(filePath);

		Scanner namesFileScanner = new Scanner(namesFile);

		String line = namesFileScanner.nextLine();

		String[] names = line.split("#");

		System.out.println(Arrays.toString(names));

		namesFileScanner.close();
	}
}