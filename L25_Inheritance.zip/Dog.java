package lessons;

class Dog extends Animal {

	@Override
	public void drink() {
		System.out.println("The dog is drinking...");
	}

	@Override
	public void eat() {
		System.out.println("The dog is eating...");
	}

	@Override
	public void sleep() {
		System.out.println("The dog is sleeping...");
	}

	@Override
	public void play() {
		System.out.println("The dog is playing...");
	}

	public void bark() {
		System.out.println("The dog is barking...");
	}
}