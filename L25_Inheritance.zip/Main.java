package lessons;

class Main {

	public static void main(String[] args) {
		Animal squirrel = new Animal();

		squirrel.eat();
		squirrel.drink();
		squirrel.play();
		squirrel.sleep();

		System.out.println();

		Dog tuzik = new Dog();

		tuzik.eat();
		tuzik.drink();
		tuzik.play();
		tuzik.sleep();
		tuzik.bark();
	}
}