package lessons;

class Animal {

	public void drink() {
		System.out.println("The animal is drinking...");
	}

	public void eat() {
		System.out.println("The animal eats...");
	}

	public void sleep() {
		System.out.println("The animal is sleeping...");
	}

	public void play() {
		System.out.println("The animal is playing...");
	}
}