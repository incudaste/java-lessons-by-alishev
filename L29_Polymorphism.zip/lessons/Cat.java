package lessons;

public class Cat extends Animal {

	public void meow() {
		System.out.println("The cat is meowing...");
	}

	@Override
	public void drink() {
		System.out.println("The cat is drinking...");
	}
}