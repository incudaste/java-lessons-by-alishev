package lessons;

public class Animal {

	public void drink() {
		System.out.println("The animal is drinking...");
	}
}