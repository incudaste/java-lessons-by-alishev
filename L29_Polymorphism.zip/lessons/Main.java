package lessons;

class Main {

	public static void main(String[] args) {
		System.out.println("-Animal class-");

		Animal animal = new Animal();

		animal.drink();

		System.out.println("\n-Dog class-");

		Dog tuzik = new Dog();

		tuzik.drink();
		tuzik.bark();

		System.out.println("\n-Cat class-");

		Cat murka = new Cat();

		murka.drink();
		murka.meow();

		System.out.println("\nDrink method (From each class): ");

		drink(animal);
		drink(tuzik);
		drink(murka);
	}

	public static void drink(Animal animal) {
		animal.drink();
	}
}