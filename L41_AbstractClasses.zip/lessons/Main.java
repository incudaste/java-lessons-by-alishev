package lessons;

public class Main {

	public static void main(String[] args) {
		Cat murka = new Cat();
		murka.eat();
		murka.makeSound();

		Dog tuzik = new Dog();
		tuzik.eat();
		tuzik.makeSound();
	}
}