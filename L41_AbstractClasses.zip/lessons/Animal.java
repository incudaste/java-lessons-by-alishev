package lessons;

public abstract class Animal {

	public void eat() {
		System.out.println("The animal is eating...");
	}

	public abstract void makeSound();
}