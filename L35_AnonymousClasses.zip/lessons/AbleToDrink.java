package lessons;

public interface AbleToDrink {

	public void drink();
}