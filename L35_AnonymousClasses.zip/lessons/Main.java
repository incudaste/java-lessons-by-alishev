package lessons;

class Main {

	public static void main(String[] args) {
		Animal wolf = new Animal();

		wolf.drink();

		AbleToDrink cat = new AbleToDrink() {
			@Override
			public void drink() {
				System.out.println("The cat is drinking...");
			}
		};

		cat.drink();
	}
}