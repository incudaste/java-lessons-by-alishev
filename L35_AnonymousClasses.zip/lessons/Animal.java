package lessons;

public class Animal implements AbleToDrink {

	@Override
	public void drink() {
		System.out.println("The animal is drinking...");
	}
}