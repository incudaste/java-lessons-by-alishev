package lessons;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enum 1 (Animal):");

		Animal dog = Animal.DOG;

		switch (dog) {
			case CAT:
				System.out.println("It's a cat.");
				break;
			case DOG:
				System.out.println("It's a dog.");
				break;
			case BIRD:
				System.out.println("It's a bird.");
				break;
			case FISH:
				System.out.println("It's a fish.");
				break;
			default:
				System.out.println("It's not an animal.");
		}

		System.out.println("\nEnum 2 (Season)");

		Season summer = Season.SUMMER;

		switch (summer) {
			case WINTER:
				System.out.println("Snow falls in the winter.");
				break;
			case SPRING:
				System.out.println("Leaves are born in spring.");
				break;
			case SUMMER:
				System.out.println("In the summer, people go to the beach.");
				break;
			case AUTUMN:
				System.out.println("In autumn, it rains outside every day.");
				break;
			default:
				System.out.println("There is no such time of year!");
		}

		System.out.println("\nSeason Enum membership: " + (summer instanceof Season));
		System.out.println("Enum Class membership: " + (summer instanceof Enum));
		System.out.println("Object Class membership: " + (summer instanceof Object));

		Animal fish = Animal.FISH;
		System.out.println("\nAnimal \"Fish\" ID: " + fish.getId());

		Season spring = Season.SPRING;
		System.out.println("Spring average temperature: " + spring.getAverageTemperature() + "°C");
	}
}