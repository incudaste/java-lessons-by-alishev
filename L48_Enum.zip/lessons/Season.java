package lessons;

public enum Season {
	WINTER(-17.5F),
	SPRING(21.0F),
	SUMMER(29.7F),
	AUTUMN(9.2F);

	private float averageTemperature;

	Season(float averageTemperature) {
		this.averageTemperature = averageTemperature;
	}

	public float getAverageTemperature() {
		return averageTemperature;
	}
}