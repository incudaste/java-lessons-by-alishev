package lessons;

public enum Animal {
	CAT(1),
	DOG(2),
	BIRD(3),
	FISH(4);

	private int id;

	Animal(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}
}