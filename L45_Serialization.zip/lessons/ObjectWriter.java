package lessons;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectWriter {

	public static void main(String[] args) throws IOException {
		Person roman = new Person(1, "Roman", (byte) 18);
		Person daniil = new Person(2, "Daniil", (byte) 21);
		Person anastasia = new Person(3, "Anastasia", (byte) 16);

		FileOutputStream fos = new FileOutputStream("people.bin");
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		oos.writeObject(roman);
		oos.writeObject(daniil);
		oos.writeObject(anastasia);

		fos.close();
		oos.close();
	}
}