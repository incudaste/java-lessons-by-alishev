package lessons;

import java.io.Serializable;

public class Person implements Serializable {

	private int id;
	private String name;
	private byte age;

	public Person(int id, String name, byte age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return id + " : " + name + " : " + age;
	}
}