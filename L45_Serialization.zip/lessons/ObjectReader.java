package lessons;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectReader {

	public static void main(String[] args) throws IOException, ReflectiveOperationException {
		FileInputStream fis = new FileInputStream("people.bin");
		ObjectInputStream ois = new ObjectInputStream(fis);

		Person roman = (Person) ois.readObject();
		Person daniil = (Person) ois.readObject();
		Person anastasia = (Person) ois.readObject();

		System.out.println(roman);
		System.out.println(daniil);
		System.out.println(anastasia);

		fis.close();
		ois.close();
	}
}