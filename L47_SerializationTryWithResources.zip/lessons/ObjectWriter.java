package lessons;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectWriter {

	public static void main(String[] args) {
		Car volvoS80 = new Car(1, "Volvo", "S80", 170);
		Car hondaCivic = new Car(2, "Honda", "Civic", 120);
		Car opelVectra = new Car(3, "Opel", "Vectra", 100);

		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("cars.bin"))) {
			oos.writeObject(volvoS80);
			oos.writeObject(hondaCivic);
			oos.writeObject(opelVectra);
		} catch (FileNotFoundException firstException) {
			firstException.printStackTrace();
		} catch (IOException secondException) {
			secondException.printStackTrace();
		}
	}
}