package lessons;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectReader {

	public static void main(String[] args) {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("cars.bin"))) {
			Car volvoS80 = (Car) ois.readObject();
			Car hondaCivic = (Car) ois.readObject();
			Car opelVectra = (Car) ois.readObject();

			System.out.println(volvoS80);
			System.out.println(hondaCivic);
			System.out.println(opelVectra);
		} catch (FileNotFoundException firstException) {
			firstException.printStackTrace();
		} catch (IOException secondException) {
			secondException.printStackTrace();
		} catch (ClassNotFoundException thirdException) {
			thirdException.printStackTrace();
		}
	}
}