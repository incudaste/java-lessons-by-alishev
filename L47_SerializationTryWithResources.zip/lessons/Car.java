package lessons;

import java.io.Serializable;

public class Car implements Serializable {

	private static final long serialVersionUID = 230324L;

	private int id;
	private String brand;
	private transient String model;
	private int enginePower;

	public Car(int id, String brand, String model, int enginePower) {
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.enginePower = enginePower;
	}

	@Override
	public String toString() {
		return id + " : " + brand + " : " + model + " : " + enginePower;
	}
}