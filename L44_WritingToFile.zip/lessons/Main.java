package lessons;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

class Main {

	public static void main(String[] args) throws FileNotFoundException {
		File randomNumbersFile = new File("Random_Numbers.txt");
		PrintWriter randomNumbersWriter = new PrintWriter(randomNumbersFile);

		for (int counter = 0; counter < 100; counter++) {
			randomNumbersWriter.println(Math.round(Math.random() * 1000));
		}

		randomNumbersWriter.close();
	}
}