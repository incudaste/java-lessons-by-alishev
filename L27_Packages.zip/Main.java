import factory.Employee;
import factory.Products;

public class Main {

	public static void main(String[] args) {
		Employee machineOperator = new Employee();

		machineOperator.setQualification("Machine operator");
		System.out.println("Employee's qualification: " + machineOperator.getQualification());

		machineOperator.setName("Vladislav");
		System.out.println("Employee's name: " + machineOperator.getName());

		machineOperator.setAge((byte) 37);
		System.out.println("Employee's age: " + machineOperator.getAge());

		machineOperator.setSalary(470.55f);
		System.out.println("Employee's salary: " + machineOperator.getSalary() + " USD");

		Products cardboardRoll = new Products();

		cardboardRoll.setId(5);
		System.out.println("\nProduct ID: " + cardboardRoll.getId());

		cardboardRoll.setName("Cardboard roll");
		System.out.println("Product name: " + cardboardRoll.getName());

		cardboardRoll.setPrice(23.49f);
		System.out.println("Product price: " + cardboardRoll.getPrice() + " USD");
	}
}