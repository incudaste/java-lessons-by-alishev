package factory;

public class Products {

	private int id;

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	private String name;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	private float price;

	public void setPrice(float price) {
		this.price = price;
	}

	public float getPrice() {
		return price;
	}
}