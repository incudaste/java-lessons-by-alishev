package factory;

public class Employee {

	private String qualification;

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getQualification() {
		return qualification;
	}

	private String name;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	private byte age;

	public void setAge(byte age) {
		this.age = age;
	}

	public byte getAge() {
		return age;
	}

	private float salary;

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public float getSalary() {
		return salary;
	}
}