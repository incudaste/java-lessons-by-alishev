package lessons;

import java.util.ArrayList;
import java.util.List;

class Main {

	public static void main(String[] args) {
		List<Animal> animals = new ArrayList<>();

		animals.add(new Animal("Cow"));
		animals.add(new Animal("Fish"));
		animals.add(new Animal("Bird"));

		System.out.println("Animals: ");
		print(animals);

		List<Dog> dogs = new ArrayList<>();

		dogs.add(new Dog("Doberman"));
		dogs.add(new Dog("Husky"));
		dogs.add(new Dog("Poodle"));

		System.out.println("\nDogs:");
		print(dogs);
	}

	private static void print(List<? extends Animal> animals) {
		for (Animal animal : animals) {
			System.out.println(animal);
		}
	}
}