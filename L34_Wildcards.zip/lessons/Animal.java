package lessons;

public class Animal {

	private String name;

	public Animal(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name;
	}

	public void drink() {
		System.out.println("The animal is drinking...");
	}
}