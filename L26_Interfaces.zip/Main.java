package lessons;

class Main {

	public static void main(String[] args) {
		Animal horse = new Animal(1);

		horse.getInfo();
		horse.sleep();

		System.out.println();

		Employee viktor = new Employee("Teacher");

		viktor.getInfo();
		viktor.toWelcome();

		System.out.println("-----");

		Information cow = new Animal(2);

		cow.getInfo();

		System.out.println();

		Information irina = new Employee("Manager");

		irina.getInfo();
	}
}