package lessons;

class Employee implements Information {

	private String position;

	public void toWelcome() {
		System.out.println("Good afternoon, pupils!");
	}

	Employee(String position) {
		this.position = position;
	}

	@Override
	public void getInfo() {
		System.out.println("Employee's position: " + position);
	}
}