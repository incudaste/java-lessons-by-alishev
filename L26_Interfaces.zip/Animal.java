package lessons;

class Animal implements Information {

	private int id;

	public void sleep() {
		System.out.println("The animal is sleeping...");
	}

	Animal(int id) {
		this.id = id;
	}

	@Override
	public void getInfo() {
		System.out.println("Animal ID: " + id);
	}
}