package lessons;

interface Information {

	public void getInfo();
}