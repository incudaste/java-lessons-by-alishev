package lessons;

class Main {

	public static void main(String[] args) {
		Dog bulldog = new Dog();

		Animal animal = bulldog; // It's upcasting! (Child -> Parent)

		System.out.println("Upcasting:");

		bulldog.drink();
		bulldog.bark();

		Dog labrador = (Dog) animal; // It's downcasting! (Parent -> Child)

		System.out.println("\nDowncasting:");

		labrador.drink();
		labrador.bark();
	}
}