package lessons;

import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.util.Scanner;

class L38_StandardException {

	public static void main(String[] args) throws IOException {
		Scanner enteredNumberScanner = new Scanner(System.in);

		while (true) {
			int enteredNumber = parseInt(enteredNumberScanner.nextLine());

			if (enteredNumber != 0) {
				try {
					throw new IOException();
				} catch (IOException exception) {
					System.out.println("You must enter zero!");
				}
			}
		}
	}
}