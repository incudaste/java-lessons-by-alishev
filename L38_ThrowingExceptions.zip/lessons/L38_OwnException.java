package lessons;

import static java.lang.Integer.parseInt;
import java.util.Scanner;

class L38_OwnException {

	public static void main(String[] args) throws ScannerException {
		Scanner enteredNumberScanner = new Scanner(System.in);

		while (true) {
			int enteredNumber = parseInt(enteredNumberScanner.nextLine());

			if (enteredNumber != 0) {
				throw new ScannerException("The user can only enter zero.");
			}
		}
	}
}