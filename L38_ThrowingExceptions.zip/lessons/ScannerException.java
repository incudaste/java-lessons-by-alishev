package lessons;

public class ScannerException extends Exception {

	public ScannerException(String description) {
		super(description);
	}
}