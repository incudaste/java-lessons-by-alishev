package lessons;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;

public class ObjectReader {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream("devices.bin");
		ObjectInputStream ois = new ObjectInputStream(fis);

		Device[] devices = (Device[]) ois.readObject();

		System.out.println(Arrays.toString(devices));

		fis.close();
		ois.close();
	}
}