package lessons;

import java.io.Serializable;

public class Device implements Serializable {

	private int id;
	private String brand;
	private float price;

	public Device(int id, String brand, float price) {
		this.id = id;
		this.brand = brand;
		this.price = price;
	}

	@Override
	public String toString() {
		return id + " : " + brand + " : " + price;
	}
}