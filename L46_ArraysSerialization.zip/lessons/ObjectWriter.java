package lessons;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectWriter {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Device[] devices = {new Device(1, "Xiaomi", 249.99F),
			                new Device(2, "Huawei", 350.99F),
			                new Device(3, "Google", 750.79F)};

		FileOutputStream fos = new FileOutputStream("devices.bin");
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		oos.writeObject(devices);

		fos.close();
		oos.close();
	}
}