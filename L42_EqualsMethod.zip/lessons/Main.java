package lessons;

class Main {

	public static void main(String[] args) {
		Car BmwM6 = new Car(16, "BMW M6", 560, 4.4F);

		Car ToyotaCamry = new Car(214, "Toyota Camry", 249, 3.5F);

		System.out.println(BmwM6.equals(ToyotaCamry));

		System.out.println("Car brand: " + (ToyotaCamry.getName().substring(0, 7)));
		System.out.println("Car model: " + (ToyotaCamry.getName().substring(7, 12)));
	}
}