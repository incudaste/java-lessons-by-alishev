package lessons;

public class Car {

	public Car(int id, String name, int enginePower, float engineDisplacement) {
		this.id = id;
		this.name = name;
		this.enginePower = enginePower;
		this.engineDisplacement = engineDisplacement;
	}

	private int id;

	public int getId() {
		return id;
	}

	private String name;

	public String getName() {
		return name;
	}

	private int enginePower;

	public int getEnginePower() {
		return enginePower;
	}

	private float engineDisplacement;

	public float getEngineDisplacement() {
		return engineDisplacement;
	}

	@Override
	public boolean equals(Object obj) {
		Car car = (Car) obj;
		return this.id == car.id;
	}
}